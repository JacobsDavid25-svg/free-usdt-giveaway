// Demo-only frontend. This user identifier is not authentication.
// Production must use verified Telegram Web App initData and a persistent database.
const demoUser = localStorage.getItem("demoUserId") || `demo_${Math.random().toString(36).slice(2, 10)}`;
localStorage.setItem("demoUserId", demoUser);

const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-Demo-User": demoUser,
      ...(options.headers || {})
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

function showMessage(id, message) {
  document.getElementById(id).textContent = message;
}

function render(user) {
  document.getElementById("balance").textContent = Number(user.balance).toFixed(4);
  document.getElementById("checkIns").textContent = user.checkIns;
  document.getElementById("referrals").textContent = user.referrals;
  document.getElementById("claimButton").disabled = !user.canClaim;
  document.getElementById("claimButton").textContent = user.canClaim
    ? "🎁 Claim daily demo reward"
    : "✓ Today's demo claim completed";
  if (user.walletAddress) document.getElementById("walletAddress").value = user.walletAddress;
}

async function refresh() {
  try {
    const user = await api("/api/status");
    render(user);
  } catch (error) {
    showMessage("claimMessage", error.message);
  }
}

document.getElementById("claimButton").addEventListener("click", async () => {
  try {
    const result = await api("/api/claim", { method: "POST", body: "{}" });
    render(result.user);
    showMessage("claimMessage", result.message);
  } catch (error) {
    showMessage("claimMessage", error.message);
  }
});

document.getElementById("checkinButton").addEventListener("click", async () => {
  try {
    const result = await api("/api/checkin", { method: "POST", body: "{}" });
    render(result.user);
    showMessage("checkinMessage", result.message);
  } catch (error) {
    showMessage("checkinMessage", error.message);
  }
});

document.getElementById("walletForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const address = document.getElementById("walletAddress").value.trim();
  try {
    const result = await api("/api/wallet", {
      method: "POST",
      body: JSON.stringify({ address })
    });
    render(result.user);
    showMessage("walletMessage", result.message);
  } catch (error) {
    showMessage("walletMessage", error.message);
  }
});

refresh();
