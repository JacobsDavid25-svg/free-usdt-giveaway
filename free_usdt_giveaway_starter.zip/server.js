const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

// DEMO ONLY: in-memory storage resets whenever the server restarts.
// Do not use this for real balances, withdrawals, or production referral rewards.
const users = new Map();

function getDemoUser(userId) {
  if (!users.has(userId)) {
    users.set(userId, {
      userId,
      balance: 0,
      lastClaimDate: null,
      checkIns: 0,
      walletAddress: "",
      referrals: 0,
      tasks: []
    });
  }
  return users.get(userId);
}

function todayUTC() {
  return new Date().toISOString().slice(0, 10);
}

function safeUser(user) {
  return {
    userId: user.userId,
    balance: user.balance,
    canClaim: user.lastClaimDate !== todayUTC(),
    checkIns: user.checkIns,
    walletAddress: user.walletAddress,
    referrals: user.referrals,
    tasks: user.tasks,
    minimumWithdrawal: 50,
    mode: "DEMO"
  };
}

// Demo identity only. The client can choose a demo name; this is NOT authentication.
// Before launch, replace this with server-side Telegram Web App initData verification.
function getDemoIdentity(req) {
  const raw = String(req.headers["x-demo-user"] || "guest").slice(0, 40);
  return raw.replace(/[^a-zA-Z0-9_-]/g, "") || "guest";
}

app.get("/api/status", (req, res) => {
  const user = getDemoUser(getDemoIdentity(req));
  res.json(safeUser(user));
});

app.post("/api/claim", (req, res) => {
  const user = getDemoUser(getDemoIdentity(req));
  if (user.lastClaimDate === todayUTC()) {
    return res.status(409).json({ error: "You have already claimed today's demo reward." });
  }
  user.lastClaimDate = todayUTC();
  user.balance = Number((user.balance + 0.1).toFixed(4));
  res.json({ message: "Demo claim added: 0.1 demo USDT.", user: safeUser(user) });
});

app.post("/api/checkin", (req, res) => {
  const user = getDemoUser(getDemoIdentity(req));
  user.checkIns += 1;
  res.json({ message: "Demo check-in recorded.", user: safeUser(user) });
});

app.post("/api/wallet", (req, res) => {
  const user = getDemoUser(getDemoIdentity(req));
  const address = String(req.body?.address || "").trim();
  if (address.length < 20 || address.length > 120 || /\s/.test(address)) {
    return res.status(400).json({ error: "Enter a valid-looking wallet address (20–120 characters, no spaces)." });
  }
  // This only stores the address in demo memory; it does not verify ownership or send funds.
  user.walletAddress = address;
  res.json({ message: "Wallet address saved for this demo only.", user: safeUser(user) });
});

app.post("/api/referral-demo", (req, res) => {
  return res.status(501).json({
    error: "Referral rewards are not enabled in this starter. Real referrals must be verified server-side."
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Free USDT Giveaway demo running on port ${PORT}`);
});
